# AURA Music — Android source + HTML import

This ZIP contains both the native Android Studio project and `index.html` for builders that require an HTML file.

## For the builder shown in your screenshot
1. Extract the ZIP into a folder on your phone.
2. In the builder, choose **Project Folder** → **Select Project Folder**.
3. Select the extracted `PremiumMusicPlayer` folder (the folder that directly contains `index.html`).
4. Continue through the remaining setup steps.

If the file picker only allows selecting a file rather than a folder, choose the `index.html` file and select the builder's HTML-file source option instead.

## HTML version
The single-file HTML app has a premium dark design and can play audio files selected from your device. Tap **Add music files**, choose one or more audio files, then tap a track. Audio access depends on the browser/builder environment; the page does not automatically scan all phone storage.

## Native Android version
Open this folder in Android Studio to build the Kotlin/Jetpack Compose app. See the Android project files for Gradle configuration.
